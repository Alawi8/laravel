@extends('layouts.app')

@section('title', 'Store - Home')
@section('homePage', 'active')

@section('content')
    <div class="page-content page-home">
        <section class="store-carousel">
            <div class="container">
            <div class="row">
                <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true">
                    <div class="carousel-indicators">
                      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner">
                      <div class="carousel-item active">
                        <img src="https://s40996.pcdn.co/wp-content/uploads/2022/01/2.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="carousel-item">
                        <img src="https://s40996.pcdn.co/wp-content/uploads/2022/01/2.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="carousel-item">
                        <img src="https://s40996.pcdn.co/wp-content/uploads/2022/01/2.jpg" class="d-block w-100" alt="...">
                      </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="visually-hidden">Next</span>
                    </button>
                  </div>
            </div>
            </div>
        </section>

        <section class="store-trend-categories">
            <div class="container">
            <div class="row">
                <div class="col-12" data-aos="fade-up">
                <h5>Trend Categories</h5>
                </div>
            </div>
            <div class="row">
                <div
                class="col-6 col-md-3 col-lg-2"
                data-aos="fade-up"
                data-aos-delay="100"
                >
                <a href="#" class="component-categories d-block">
                    <div class="categories-image">
                    <img src="images/icon-gadgets.svg" alt="alt" class="w-100" />
                    </div>
                    <p class="categories-text">Gadgets</p>
                </a>
                </div>
                <div
                class="col-6 col-md-3 col-lg-2"
                data-aos="fade-up"
                data-aos-delay="200"
                >
                <a href="#" class="component-categories d-block">
                    <div class="categories-image">
                    <img src="images/icon-furniture.svg" alt="" class="w-100" />
                    </div>
                    <p class="categories-text">Furniture</p>
                </a>
                </div>
                <div
                class="col-6 col-md-3 col-lg-2"
                data-aos="fade-up"
                data-aos-delay="300"
                >
                <a href="#" class="component-categories d-block">
                    <div class="categories-image">
                    <img src="images/icon-makeup.svg" alt="" class="w-100" />
                    </div>
                    <p class="categories-text">Make Up</p>
                </a>
                </div>
                <div
                class="col-6 col-md-3 col-lg-2"
                data-aos="fade-up"
                data-aos-delay="400"
                >
                <a href="#" class="component-categories d-block">
                    <div class="categories-image">
                    <img src="images/icon-sneaker.svg" alt="" class="w-100" />
                    </div>
                    <p class="categories-text">Sneaker</p>
                </a>
                </div>
                <div
                class="col-6 col-md-3 col-lg-2"
                data-aos="fade-up"
                data-aos-delay="500"
                >
                <a href="#" class="component-categories d-block">
                    <div class="categories-image">
                    <img src="images/icon-tools.svg" alt="" class="w-100" />
                    </div>
                    <p class="categories-text">Tools</p>
                </a>
                </div>
                <div
                class="col-6 col-md-3 col-lg-2"
                data-aos="fade-up"
                data-aos-delay="600"
                >
                <a href="#" class="component-categories d-block">
                    <div class="categories-image">
                    <img src="images/icon-baby.svg" alt="" class="w-100" />
                    </div>
                    <p class="categories-text">Baby</p>
                </a>
                </div>
            </div>
            </div>
        </section>

        <section class="store-new-products">
            <div class="container">
            <div class="row">
                <div class="col-12" data-aos="fade-up">
                <h5>New Products</h5>
                </div>
            </div>
            <div class="row">
                <div
                class="col-6 col-md-4 col-lg-3"
                data-aos="fade-up"
                data-aos-delay="100"
                >
                <a href="/details.html" class="component-products d-block">
                    <div class="products-thumbnail">
                    <div
                        class="products-image"
                        style="background-image: url('/images/product-1.jpg')"
                    ></div>
                    </div>
                    <div class="products-text">Apple Watch 4</div>
                    <div class="products-price">$890</div>
                </a>
                </div>
                <div
                class="col-6 col-md-4 col-lg-3"
                data-aos="fade-up"
                data-aos-delay="200"
                >
                <a href="/details.html" class="component-products d-block">
                    <div class="products-thumbnail">
                    <div
                        class="products-image"
                        style="background-image: url('/images/product-2.jpg')"
                    ></div>
                    </div>
                    <div class="products-text">Orange Bogotta</div>
                    <div class="products-price">$94,509</div>
                </a>
                </div>
                <div
                class="col-6 col-md-4 col-lg-3"
                data-aos="fade-up"
                data-aos-delay="300"
                >
                <a href="/details.html" class="component-products d-block">
                    <div class="products-thumbnail">
                    <div
                        class="products-image"
                        style="background-image: url('/images/product-3.jpg')"
                    ></div>
                    </div>
                    <div class="products-text">Sofa Ternyaman</div>
                    <div class="products-price">$1,409</div>
                </a>
                </div>
                <div
                class="col-6 col-md-4 col-lg-3"
                data-aos="fade-up"
                data-aos-delay="400"
                >
                <a href="/details.html" class="component-products d-block">
                    <div class="products-thumbnail">
                    <div
                        class="products-image"
                        style="background-image: url('/images/product-4.jpg')"
                    ></div>
                    </div>
                    <div class="products-text">Bubuk Maketti</div>
                    <div class="products-price">$225</div>
                </a>
                </div>
                <div
                class="col-6 col-md-4 col-lg-3"
                data-aos="fade-up"
                data-aos-delay="500"
                >
                <a href="/details.html" class="component-products d-block">
                    <div class="products-thumbnail">
                    <div
                        class="products-image"
                        style="background-image: url('/images/product-5.jpg')"
                    ></div>
                    </div>
                    <div class="products-text">Tatakan Gelas</div>
                    <div class="products-price">$45,184</div>
                </a>
                </div>
                <div
                class="col-6 col-md-4 col-lg-3"
                data-aos="fade-up"
                data-aos-delay="600"
                >
                <a href="/details.html" class="component-products d-block">
                    <div class="products-thumbnail">
                    <div
                        class="products-image"
                        style="background-image: url('/images/product-6.jpg')"
                    ></div>
                    </div>
                    <div class="products-text">Mavic Kawe</div>
                    <div class="products-price">$503</div>
                </a>
                </div>
                <div
                class="col-6 col-md-4 col-lg-3"
                data-aos="fade-up"
                data-aos-delay="700"
                >
                <a href="/details.html" class="component-products d-block">
                    <div class="products-thumbnail">
                    <div
                        class="products-image"
                        style="background-image: url('/images/product-7.jpg')"
                    ></div>
                    </div>
                    <div class="products-text">Black Edition Nike</div>
                    <div class="products-price">$70,482</div>
                </a>
                </div>
                <div
                class="col-6 col-md-4 col-lg-3"
                data-aos="fade-up"
                data-aos-delay="700"
                >
                <a href="/details.html" class="component-products d-block">
                    <div class="products-thumbnail">
                    <div
                        class="products-image"
                        style="background-image: url('/images/product-8.jpg')"></div>
                    </div>
                    <div class="products-text">Monkey Toys</div>
                    <div class="products-price">$783</div>
                </a>
                </div>
            </div>
            </div>
        </section>
    </div>
@endsection
