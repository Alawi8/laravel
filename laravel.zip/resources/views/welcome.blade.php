@extends ('layouts.app')

@section('content')
    im content home
@endsection
