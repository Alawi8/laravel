<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    

    <title>Document</title>
</head>

<body>
    <?php $__env->startSection('content'); ?>
soft delete
        <div class="">
            <div class="row">
                <?php $__currentLoopData = $futs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xxl-2 col-lg-3 col-md-4 col-sm-6">
                        <a class="nav-link active" href="#">
                        <div class="card" >
                            <img src="https://www.apple.com/newsroom/images/product/os/macos/standard/Apple-WWDC22-macOS-Ventura-Spotlight-show-220606_big.jpg.large.jpg"
                                class="card-img-top" alt="...">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($fut->title); ?></h5>
                                <p class="card-text"><?php echo e($fut->body); ?></p>
                                <p class="card-text"><?php echo e($fut->created_at); ?></p>
                                <a href="<?php echo e(route('fut.restore',$fut->id)); ?>" class="btn btn-primary">restore</a>

                                <form action="<?php echo e(route('fut.forceDelete',$fut->id)); ?>" method="post">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger">DELETE</button>
                                </form>
                            </div>
                        </div>
                    </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('../layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/fut/softDelete.blade.php ENDPATH**/ ?>