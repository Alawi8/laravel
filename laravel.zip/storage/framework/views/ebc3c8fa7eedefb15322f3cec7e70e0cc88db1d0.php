
<form action="<?php echo e(route('admin.update',$posts->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="title" value="<?php echo e($posts->title); ?>">
    <input type="text" name="body" value="<?php echo e($posts->body); ?>">
    <button type="submit">submit update</button>
</form><?php /**PATH C:\xampp\htdocs\laravel\resources\views/admin/update.blade.php ENDPATH**/ ?>