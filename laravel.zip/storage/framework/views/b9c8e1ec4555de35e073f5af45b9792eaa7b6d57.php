
<?php $__env->startSection('content'); ?>
    
<form action="<?php echo e(route('posts.insert')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="title" placeholder="enter title">
    <input type="text" name="body" placeholder="enter title">
    <button type="submit">submit</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/posts/create.blade.php ENDPATH**/ ?>