
<form action="<?php echo e(route('admin.add',$posts-> id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="title" value="<?php echo e($posts->title); ?>">
    <input type="text" name="body" value="<?php echo e($posts->body); ?>">
    <button type="submit">submit</button>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/admin/edit.blade.php ENDPATH**/ ?>