
 
<?php $__env->startSection('title', 'Page Title'); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
 
    <p>This is appended to the master sidebar.</p>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
    <p>im content users</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/users.blade.php ENDPATH**/ ?>