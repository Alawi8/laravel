
  <?php $__env->startSection('content'); ?>
      
  <h1>create new posts</h1>
  
  <form action="<?php echo e(route('admin.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input class="" type="text" name="title" placeholder="enter title">
    <input  type="text" name="body" placeholder="enter body">
    <input type="datetime">
    <button type="submit">submit data</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('./layout/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/admin/create.blade.php ENDPATH**/ ?>