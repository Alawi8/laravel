

<?php $__env->startSection('content'); ?>
    
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="card" style="width: 18rem;">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($post->title); ?></h5>
              <p class="card-text"><?php echo e($post->body); ?></p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
            <h1></h1>
            <p></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/posts/index.blade.php ENDPATH**/ ?>